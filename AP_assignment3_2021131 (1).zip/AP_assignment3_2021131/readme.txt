
APassignment3A folder cotains Part-A's Readme and its buildfile (pom.xml) and the sources(code).

------------------------------------------------

APassignment3B folder cotains Part-B's Readme and its buildfile (pom.xml) and the sources(code).