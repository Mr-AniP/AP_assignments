To run Part-B->

Open cmd  and change directory to the folder Partb in the submision folder and run the following command one by one ->

	mvn package

	java -cp target/APassignment3B-1.0-SNAPSHOT.jar apassignment3AP.Main
