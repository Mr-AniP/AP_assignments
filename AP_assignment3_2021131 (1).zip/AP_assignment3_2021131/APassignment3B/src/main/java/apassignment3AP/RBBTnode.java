package apassignment3AP;

public class RBBTnode {
    RBBTnode left=null;
    RBBTnode right=null;
    long val;
    int height;
    public RBBTnode(long x){
        val=x;
    }
}
