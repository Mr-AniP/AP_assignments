module future2builder {
	requires java.desktop;
	requires java.base;
}